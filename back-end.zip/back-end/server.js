const express = require("express");
const sql = require("mssql");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

// ================================
// CONFIG SQL SERVER (Windows Auth)
// ================================
const dbConfig = {
  server: "localhost",      // ✅ ใช้ localhost
  database: "ThaiPBS_DB",
  user: "sa",
  password: "StrongPass123",
  port: 1433,               // ✅ พอร์ตที่เช็กได้แล้ว
  options: {
    trustServerCertificate: true,
    enableArithAbort: true,
  },
};

// ================================
// TEST API
// ================================
app.get("/", (req, res) => {
  res.send("API is running");
});

// ================================
// API: ดึงข้อมูลข่าวทั้งหมด
// ================================
app.get("/api/news", async (req, res) => {
  try {
    await sql.connect(dbConfig);
    const result = await sql.query("SELECT * FROM dbo.News");
    res.json(result.recordset);
  } catch (err) {
    console.error("DB ERROR:", err);
    res.status(500).json({ error: err.message });
  }
});

// ================================
// API: ดึงข่าวตาม ID
// ================================
app.get("/api/news/:id", async (req, res) => {
  try {
    await sql.connect(dbConfig);

    const { id } = req.params;

    const request = new sql.Request();
    request.input("id", sql.Int, id);

    const result = await request.query(
      "SELECT * FROM dbo.News WHERE id = @id"
    );

    res.json(result.recordset[0]);
  } catch (err) {
    console.error("DB ERROR:", err);
    res.status(500).json({ error: err.message });
  }

 // ================================
 // API: ค้นหาคนหาย (ตามเดือน + ชื่อ)
 // ================================
 app.get("/api/missing-persons", async (req, res) => {
  const { month, name } = req.query;

  try {
    await sql.connect(dbConfig);

    const result = await sql.query`
      SELECT *
      FROM MissingPerson
      WHERE
        (${month} IS NULL OR missing_month = ${month})
        AND (${name} IS NULL OR missing_name LIKE N'%' + ${name} + N'%')
    `;

    res.json(result.recordset);
  } catch (err) {
    console.error("DB ERROR:", err);
    res.status(500).json({ error: err.message });
  }
 });




});
// ================================
// API: เพิ่มข่าวใหม่ (POST)
// ================================
app.post("/api/news", async (req, res) => {
  try {
    const { title, description } = req.body;

    await sql.connect(dbConfig);

    await sql.query`
      INSERT INTO dbo.News (title, description)
      VALUES (${title}, ${description})
    `;

    res.json({ message: "News created successfully" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
// ================================
// API: แก้ไขข่าว (PUT)
// ================================
app.put("/api/news/:id", async (req, res) => {
  const { id } = req.params;
  const { title, description } = req.body;

  try {
    await sql.connect(dbConfig);

    await sql.query`
      UPDATE dbo.News
      SET title = ${title},
          description = ${description}
      WHERE id = ${id}
    `;

    res.json({ message: "News updated successfully" });
  } catch (err) {
    console.error("DB ERROR:", err);
    res.status(500).json({ error: err.message });
  }
});

// ================================
// API: ลบข่าว
// ================================
app.delete("/api/news/:id", async (req, res) => {
  const { id } = req.params;

  try {
    await sql.connect(dbConfig);

    await sql.query`
      DELETE FROM dbo.News
      WHERE id = ${id}
    `;

    res.json({ message: "Deleted successfully" });
  } catch (err) {
    console.error("DB ERROR:", err);
    res.status(500).json({ error: err.message });
  }
});




// ================================
// START SERVER
// ================================
app.listen(3000, () => {
  console.log("Server running at http://localhost:3000");
});
